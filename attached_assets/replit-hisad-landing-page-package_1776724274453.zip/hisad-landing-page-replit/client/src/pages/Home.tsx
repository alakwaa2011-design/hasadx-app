/*
Style reminder for this page:
- فلسفة الملف: حصاد منصة عربية احترافية للمسابقات التفاعلية والواجبات والاختبارات، موجهة للمعلم وتُشعر الطالب بالحماس.
- الأولوية البصرية: هوية المسابقات واضحة من أول شاشة، مع كود دخول بارز، ثم فيديو تفاعلي يشبه تجربة الطالب داخل المنصة.
- الخطوط والأحجام: عربية، أهدأ، أوضح، وأقل تضخمًا من النسخة السابقة.
*/
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  ClipboardCheck,
  FileText,
  GraduationCap,
  PlayCircle,
  Sparkles,
  TimerReset,
  Trophy,
  Users,
  Video,
} from "lucide-react";
import { toast } from "sonner";

const featureCards = [
  {
    title: "مسابقات مباشرة",
    description: "سؤال، وقت، ترتيب، وتفاعل لحظي داخل الصف.",
    icon: Trophy,
    tone: "bg-[#e5f3ea] text-primary",
  },
  {
    title: "واجبات واختبارات",
    description: "إنشاء أسرع ومتابعة أوضح من واجهة واحدة.",
    icon: ClipboardCheck,
    tone: "bg-[#f4eddd] text-[#8a6d33]",
  },
  {
    title: "كود دخول من 6 أرقام",
    description: "واضح وسريع ليستخدمه الطالب دائمًا دون تعقيد.",
    icon: Users,
    tone: "bg-[#e8f0f7] text-[#355c82]",
  },
];

const tools = [
  {
    title: "المسابقات التفاعلية",
    description: "أسئلة حية، مؤقت، ولوحة نتائج تبقي الصف متحمسًا.",
    icon: Trophy,
  },
  {
    title: "الأنشطة التعليمية",
    description: "أنشطة قصيرة أو ممتدة تخدم الدرس اليومي بسهولة.",
    icon: Sparkles,
  },
  {
    title: "الواجبات المنظمة",
    description: "إنشاء وتسليم ومتابعة داخل تجربة أوضح للمعلم.",
    icon: FileText,
  },
  {
    title: "الاختبارات السريعة",
    description: "نتائج أسرع وقياس فوري للفهم والمشاركة.",
    icon: ClipboardCheck,
  },
  {
    title: "الفيديو التفاعلي",
    description: "اعرض الفيديو ثم أظهر سؤالًا مباشرًا كما يراه الطالب داخل المنصة.",
    icon: Video,
  },
];

const steps = [
  {
    title: "أنشئ النشاط خلال دقائق",
    description: "ابدأ من مسابقة أو واجب أو اختبار أو فيديو تفاعلي جاهز للتخصيص.",
  },
  {
    title: "شارك كودًا من 6 أرقام",
    description: "يدخل الطالب الكود بسرعة ويبدأ دون تسجيل معقّد.",
  },
  {
    title: "تابع التفاعل والنتائج",
    description: "شاهد المشاركة والتقدّم والتسليمات من لوحة واضحة ومباشرة.",
  },
];

const stats = [
  { value: "+737", label: "طالبًا مشاركًا", note: "نشاط حي داخل المسابقات" },
  { value: "+61", label: "مسابقة واختبارًا", note: "نماذج متنوّعة للصف" },
  { value: "+26", label: "معلّمًا نشطًا", note: "استخدام متكرر أثناء الحصص" },
  { value: "+67", label: "تسليمًا مكتملًا", note: "متابعة أسهل للواجبات" },
];

const quizChoices = [
  { badge: "أ", label: "التكاثف", color: "bg-[#cb4747]" },
  { badge: "ب", label: "التبخر", color: "bg-[#2f5ea8]" },
  { badge: "ج", label: "الهطول", color: "bg-[#2e9465]" },
  { badge: "د", label: "الجريان السطحي", color: "bg-[#cea648]" },
];

const videoChoices = [
  { badge: "A", label: "عندما ترتفع حرارة الشمس" },
  { badge: "B", label: "عندما يهبط المطر إلى الأرض" },
  { badge: "C", label: "عندما يتجمّع الماء في السحب" },
  { badge: "D", label: "عندما يتسرب الماء إلى التربة" },
];

const joinDigits = ["4", "8", "3", "9", "2", "1"];

export default function Home() {
  const notify = (message: string) => toast.success(message);

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground selection:bg-primary/15 selection:text-primary">
      <main className="overflow-hidden">
        <section className="relative border-b border-border/70">
          <div className="hero-veil pointer-events-none absolute inset-0" />
          <div className="hero-noise pointer-events-none absolute inset-0 opacity-55" />

          <div className="container relative z-10 py-6 sm:py-8 lg:py-10">
            <header className="glass-panel flex items-center justify-between gap-4 rounded-[26px] px-4 py-3 sm:px-6">
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-[0.68rem] font-semibold tracking-[0.22em] text-primary/75">HISAD</p>
                  <h1 className="text-lg font-extrabold text-foreground sm:text-[1.45rem]">حصاد</h1>
                </div>
                <div className="logo-shell shadow-[0_18px_34px_rgba(43,97,67,0.18)]">
                  <span className="text-xl font-black text-primary-foreground">ح</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  className="rounded-2xl border-border bg-white/85 px-5 text-sm font-semibold text-foreground hover:bg-white"
                  onClick={() => notify("يمكنك ربط صفحة الدخول لاحقًا.")}
                >
                  دخول
                </Button>
                <button
                  type="button"
                  onClick={() => notify("يمكنك ربط القائمة الداخلية بالصفحات لاحقًا.")}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-border bg-white/85 text-foreground transition hover:-translate-y-0.5 hover:shadow-[0_16px_24px_rgba(32,74,52,0.08)]"
                  aria-label="القائمة"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="stroke-[2.1] text-foreground">
                    <path d="M4 7H20" stroke="currentColor" strokeLinecap="round" />
                    <path d="M4 12H20" stroke="currentColor" strokeLinecap="round" />
                    <path d="M4 17H14" stroke="currentColor" strokeLinecap="round" />
                  </svg>
                </button>
              </div>
            </header>

            <div className="grid items-center gap-10 pb-8 pt-10 lg:grid-cols-[1fr_1.02fr] lg:gap-12 lg:pb-12 lg:pt-14">
              <div className="order-2 space-y-6 lg:order-1">
                <div className="inline-flex items-center gap-2 rounded-full border border-[#d8e6db] bg-white/92 px-4 py-2 text-sm font-semibold text-primary shadow-[0_10px_30px_rgba(59,116,82,0.08)] backdrop-blur">
                  <GraduationCap className="h-4 w-4" />
                  منصة عربية للمسابقات التفاعلية
                </div>

                <div className="space-y-4">
                  <h2 className="hero-title max-w-2xl text-balance text-[2rem] font-black leading-[1.14] text-foreground sm:text-[2.7rem] lg:text-[3.35rem]">
                    منصتك لإنشاء المسابقات والأنشطة التعليمية
                  </h2>
                  <p className="max-w-xl text-[0.98rem] leading-8 text-muted-foreground sm:text-[1.04rem]">
                    أنشئ مسابقة أو واجبًا أو اختبارًا أو فيديو تفاعليًا، ثم شارك الطلاب بكود من 6 أرقام وتابع التفاعل من لوحة مريحة للمعلم.
                  </p>
                </div>

                <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                  <Button
                    size="lg"
                    className="h-13 rounded-2xl px-7 text-[0.98rem] font-bold shadow-[0_20px_40px_rgba(45,103,71,0.24)]"
                    onClick={() => notify("يمكن ربط زر إنشاء المسابقة أو النشاط بالتدفق الفعلي لاحقًا.")}
                  >
                    ابدأ أول مسابقة الآن
                    <ArrowLeft className="mr-2 h-4 w-4" />
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="h-13 rounded-2xl border-border bg-white/88 px-7 text-[0.98rem] font-bold text-foreground hover:bg-white"
                    onClick={() => notify("يمكن عرض النماذج الجاهزة في صفحة مستقلة لاحقًا.")}
                  >
                    تصفّح النماذج الجاهزة
                  </Button>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  {featureCards.map(({ title, description, icon: Icon, tone }) => (
                    <div key={title} className="soft-card rounded-[24px] p-4 transition-transform duration-300 hover:-translate-y-1">
                      <div className={`mb-2 inline-flex rounded-2xl p-2 ${tone}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <p className="text-[1rem] font-extrabold text-foreground">{title}</p>
                      <p className="mt-1 text-sm leading-6 text-muted-foreground">{description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="order-1 lg:order-2">
                <div className="relative mx-auto max-w-[41rem]">
                  <div className="floating-badge animate-float-soft right-4 top-4 hidden sm:block">
                    <span className="text-xl font-black text-[#79f2b1]">98%</span>
                    <span className="text-sm font-bold text-white/88">مباشر الآن</span>
                  </div>

                  <div className="hero-stage relative overflow-hidden rounded-[34px] p-4 sm:p-6">
                    <div className="absolute inset-x-0 top-0 h-40 bg-[radial-gradient(circle_at_top,rgba(122,242,177,0.16),transparent_60%)]" />
                    <div className="relative z-10 rounded-[28px] border border-white/10 bg-white/5 p-4 sm:p-6 backdrop-blur-md">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
                        <div>
                          <p className="text-[0.72rem] font-bold tracking-[0.18em] text-[#9ddfbd]">LIVE QUIZ</p>
                          <h3 className="mt-2 text-[1.6rem] font-black text-white sm:text-[2.15rem]">مسابقة العلوم — الفصل الثالث</h3>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="rounded-full bg-white/8 px-4 py-2 text-sm font-bold text-white/90">السؤال 3 من 10</div>
                          <div className="pulse-ring rounded-full bg-[#123f2b] px-4 py-2 text-sm font-black text-[#9df5be]">00:18</div>
                        </div>
                      </div>

                      <div className="mt-5 rounded-[24px] border border-white/10 bg-white/6 px-5 py-6 sm:px-6">
                        <p className="text-sm font-semibold text-white/60">سؤال مباشر</p>
                        <p className="mt-3 text-[1.55rem] font-black leading-[1.6] text-white sm:text-[2rem]">
                          ما المرحلة التي يتحول فيها الماء إلى بخار؟
                        </p>
                      </div>

                      <div className="mt-5 grid gap-4 sm:grid-cols-2">
                        {quizChoices.map((choice) => (
                          <button
                            key={choice.label}
                            type="button"
                            onClick={() => notify(`يمكن ربط خيار ${choice.label} بتجربة المسابقة الفعلية لاحقًا.`)}
                            className={`quiz-option ${choice.color} rounded-[22px] px-5 py-4 text-right text-[1rem] font-black text-white shadow-[0_16px_28px_rgba(0,0,0,0.22)] transition duration-300 hover:-translate-y-1`}
                          >
                            <span className="flex items-center justify-between gap-3">
                              <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-white/16 text-sm font-black text-white/90">
                                {choice.badge}
                              </span>
                              <span>{choice.label}</span>
                            </span>
                          </button>
                        ))}
                      </div>

                      <div className="mt-6 flex flex-col gap-4 border-t border-white/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex items-center gap-2 text-white/80">
                          <Users className="h-4 w-4 text-[#92f4b9]" />
                          <span className="text-sm font-semibold">24 طالبًا مشاركًا الآن</span>
                        </div>
                        <div className="countdown-wrap flex-1">
                          <div className="countdown-track" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="soft-card rounded-[30px] p-6 sm:p-7">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-bold text-primary">الدخول السريع للطلاب</p>
                    <h3 className="mt-2 text-[1.6rem] font-black text-foreground sm:text-[2rem]">أدخل كود المسابقة — 6 أرقام فقط</h3>
                    <p className="mt-2 max-w-lg text-sm leading-7 text-muted-foreground">
                      لأن الطالب يستخدمه دائمًا، جعلناه أوضح وأسرع وأسهل للحفظ.
                    </p>
                  </div>
                  <div className="rounded-[24px] border border-[#dfe8de] bg-[#fbfcf9] px-4 py-3 text-sm font-semibold text-primary">
                    كود واضح وسريع للانضمام
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  {joinDigits.map((digit, index) => (
                    <div key={`${digit}-${index}`} className="digit-slot animate-float-soft text-lg font-black text-foreground">
                      {digit}
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                  <label className="sr-only" htmlFor="join-code">
                    كود المسابقة المكوّن من 6 أرقام
                  </label>
                  <input
                    id="join-code"
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="123456"
                    className="h-14 flex-1 rounded-2xl border border-border bg-white px-5 text-left text-lg font-black tracking-[0.35em] outline-none transition placeholder:text-muted-foreground/80 focus:border-primary focus:ring-4 focus:ring-primary/10"
                  />
                  <Button className="h-14 rounded-2xl px-8 text-base font-bold" onClick={() => notify("يمكن ربط الانضمام بالكود بالمسار الفعلي لاحقًا.")}>انضم الآن</Button>
                </div>
              </div>

              <div className="soft-card rounded-[30px] bg-[linear-gradient(180deg,rgba(244,236,218,0.88),rgba(255,255,255,0.96))] p-6 sm:p-7">
                <p className="text-sm font-bold text-[#7a6537]">للمعلم</p>
                <h3 className="mt-2 text-[1.6rem] font-black text-foreground sm:text-[2rem]">واجهة حية تشعر الطالب بالحماس وتريحك في الإدارة</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">
                  من المسابقة السريعة إلى الفيديو التفاعلي والواجبات، كل مسار مصمم ليظهر بصورة واضحة واحترافية داخل صفك.
                </p>
                <Button
                  variant="outline"
                  className="mt-5 rounded-2xl border-[#decba2] bg-white/92 px-6 font-bold text-foreground hover:bg-white"
                  onClick={() => notify("يمكن ربط هذه الدعوة باستعراض الخدمات لاحقًا.")}
                >
                  استكشف الخدمات
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="container py-16 sm:py-20">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <p className="text-sm font-bold text-primary">خدمات أساسية داخل حصاد</p>
              <h3 className="mt-3 text-[2rem] font-black text-foreground sm:text-[2.6rem]">كل ما يحتاجه المعلم في منصة واحدة</h3>
            </div>
            <p className="max-w-xl text-[0.98rem] leading-8 text-muted-foreground">
              ركّزنا على ما يحتاجه الاستخدام اليومي فعلًا: مسابقات، أنشطة، واجبات، اختبارات، وفيديو تفاعلي يظهر أسئلته بوضوح داخل التجربة.
            </p>
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-5">
            {tools.map(({ title, description, icon: Icon }) => (
              <article
                key={title}
                className="group soft-card rounded-[28px] p-5 transition duration-300 hover:-translate-y-1.5 hover:shadow-[0_28px_58px_rgba(42,80,57,0.12)]"
              >
                <div className="inline-flex rounded-[18px] border border-white/90 bg-white/90 p-3 text-primary shadow-[0_14px_26px_rgba(53,102,71,0.08)]">
                  <Icon className="h-5 w-5" />
                </div>
                <h4 className="mt-4 text-[1.1rem] font-black text-foreground">{title}</h4>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="relative overflow-hidden border-y border-border/70 bg-[#fbfcf8]">
          <div className="container relative py-16 sm:py-20">
            <div className="grid items-start gap-6 lg:grid-cols-[0.92fr_1.08fr]">
              <div className="video-stage rounded-[34px] p-5 text-white shadow-[0_30px_70px_rgba(76,55,18,0.18)] sm:p-6">
                <div className="flex items-center justify-between gap-3 text-sm">
                  <span className="live-chip">بث تعليمي تفاعلي</span>
                  <span className="text-white/88">رحلة الماء في الطبيعة</span>
                </div>

                <div className="mt-5 overflow-hidden rounded-[28px] border border-white/20 bg-[linear-gradient(180deg,rgba(198,149,73,0.86),rgba(235,192,113,0.92))] p-5">
                  <div className="video-overlay rounded-[22px] border border-[#8b6a2f]/18 bg-black/10 p-4 sm:p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-sm font-bold text-[#fff4d9]">فيديو تفاعلي</p>
                        <h3 className="mt-2 text-[1.55rem] font-black text-white sm:text-[1.9rem]">دورة الماء</h3>
                        <p className="mt-1 text-sm text-white/82">شاهد المقطع ثم أجب مباشرة كما يراه الطالب داخل حصاد.</p>
                      </div>
                      <div className="rounded-full bg-white/88 px-4 py-2 text-sm font-bold text-[#8a6727]">00:42</div>
                    </div>

                    <div className="mt-6 flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => notify("يمكن ربط الفيديو التفاعلي الفعلي هنا لاحقًا.")}
                        className="group inline-flex h-20 w-20 items-center justify-center rounded-full bg-white/22 text-white shadow-[0_18px_36px_rgba(0,0,0,0.2)] backdrop-blur transition hover:scale-105"
                        aria-label="تشغيل الفيديو"
                      >
                        <PlayCircle className="h-12 w-12 transition group-hover:scale-105" />
                      </button>
                    </div>

                    <div className="mt-6 flex items-center justify-between text-sm text-white/86">
                      <span>المشهد 2 من 5</span>
                      <span>سؤال سيظهر بعد 8 ثوانٍ</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 rounded-[28px] bg-white/92 p-5 text-foreground shadow-[0_18px_34px_rgba(67,52,24,0.1)]">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-[#9a7a3b]">السؤال بعد الفيديو</p>
                      <h4 className="mt-1 text-[1.35rem] font-black sm:text-[1.6rem]">متى يبدأ التبخر في دورة الماء؟</h4>
                    </div>
                    <div className="rounded-full bg-[#f6edda] px-4 py-2 text-sm font-black text-[#8d6f33]">08 ث</div>
                  </div>

                  <div className="mt-5 space-y-3">
                    {videoChoices.map((choice) => (
                      <button
                        key={choice.badge}
                        type="button"
                        onClick={() => notify(`يمكن ربط خيار ${choice.label} بتجربة الفيديو التفاعلي لاحقًا.`)}
                        className="video-answer w-full rounded-[22px] border border-[#ece4d1] bg-white px-5 py-4 text-right transition duration-300 hover:-translate-y-0.5 hover:border-[#d8c79e]"
                      >
                        <span className="flex items-center justify-between gap-3">
                          <span className="text-[0.96rem] font-bold text-foreground sm:text-[1rem]">{choice.label}</span>
                          <span className="inline-flex h-10 min-w-10 items-center justify-center rounded-full bg-[#f7f2e5] px-3 text-sm font-black text-[#7f6129]">
                            {choice.badge}
                          </span>
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="soft-card rounded-[34px] p-7 sm:p-8">
                <p className="text-sm font-bold text-primary">الفيديو التفاعلي داخل حصاد</p>
                <h3 className="mt-3 text-[2rem] font-black text-foreground sm:text-[2.6rem]">شاهد ثم اسأل ثم تفاعل</h3>
                <p className="mt-4 text-[0.98rem] leading-8 text-muted-foreground">
                  بدل أن يكون الفيديو مشاهدة فقط، يتحول في حصاد إلى تجربة تعليمية نشطة: مقطع واضح، توقيت جذاب، ثم سؤال فوري يختبر الفهم ويزيد المشاركة.
                </p>

                <div className="mt-7 space-y-4">
                  <div className="rounded-[24px] border border-border bg-white p-5 shadow-[0_16px_32px_rgba(48,89,66,0.06)]">
                    <div className="flex items-center gap-3">
                      <div className="inline-flex rounded-2xl bg-[#e8f2ea] p-3 text-primary">
                        <Video className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-[1.05rem] font-black text-foreground">واجهة أقرب لتجربة الطالب</h4>
                        <p className="mt-1 text-sm leading-7 text-muted-foreground">بطاقة فيديو في الأعلى، ثم سؤال واضح بخيارات مريحة كما يظهر داخل المنصة.</p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-[24px] border border-border bg-white p-5 shadow-[0_16px_32px_rgba(48,89,66,0.06)]">
                    <div className="flex items-center gap-3">
                      <div className="inline-flex rounded-2xl bg-[#f5ecdb] p-3 text-[#8a6d33]">
                        <TimerReset className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-[1.05rem] font-black text-foreground">توقيت وحماس بدون ازدحام</h4>
                        <p className="mt-1 text-sm leading-7 text-muted-foreground">مؤقت واضح، حركة ناعمة، وخطوط أخف حتى تبدو الصفحة أكثر احترافية وأقل صخبًا.</p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-[24px] border border-border bg-white p-5 shadow-[0_16px_32px_rgba(48,89,66,0.06)]">
                    <div className="flex items-center gap-3">
                      <div className="inline-flex rounded-2xl bg-[#ebf1f8] p-3 text-[#355c82]">
                        <Users className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-[1.05rem] font-black text-foreground">مفيد للمعلم من أول نظرة</h4>
                        <p className="mt-1 text-sm leading-7 text-muted-foreground">الواجهة تقول بوضوح إن حصاد للمعلم الذي يريد إمتاع طلابه وتنظيم أنشطته وواجباته واختباراته.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="container py-16 sm:py-20">
          <div className="grid gap-6 lg:grid-cols-[0.92fr_1.08fr]">
            <div className="soft-card rounded-[34px] p-7 sm:p-8">
              <p className="text-sm font-bold text-primary">كيف يعمل حصاد</p>
              <h3 className="mt-3 text-[2rem] font-black text-foreground sm:text-[2.6rem]">من الفكرة إلى التفاعل في ثلاث خطوات</h3>
              <div className="mt-8 space-y-5">
                {steps.map((step, index) => (
                  <div key={step.title} className="flex gap-4 rounded-[24px] border border-border/80 bg-white/92 p-5 transition duration-300 hover:-translate-y-1 hover:shadow-[0_20px_35px_rgba(44,92,63,0.08)]">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#e3efe7] text-lg font-black text-primary">
                      {index + 1}
                    </div>
                    <div>
                      <h4 className="text-[1.04rem] font-black text-foreground">{step.title}</h4>
                      <p className="mt-2 text-sm leading-7 text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="soft-card rounded-[34px] p-7 sm:p-8">
              <p className="text-sm font-bold text-primary">إحصائيات متحركة</p>
              <h3 className="mt-3 text-[2rem] font-black text-foreground sm:text-[2.6rem]">أرقام نشطة لا تبدو جامدة</h3>
              <p className="mt-4 text-[0.98rem] leading-8 text-muted-foreground">
                أضفنا إيقاعًا بصريًا أخف إلى الإحصائيات حتى تشعر بالحركة من دون مبالغة أو ضجيج.
              </p>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {stats.map((item, index) => (
                  <article key={item.label} className="animated-stat rounded-[28px] border border-border/70 bg-white p-5 shadow-[0_18px_40px_rgba(48,89,66,0.07)]">
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-[2rem] font-black tracking-tight text-primary sm:text-[2.4rem]">{item.value}</p>
                      <span className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${index % 2 === 0 ? "bg-[#e3f2e9] text-primary" : "bg-[#f4ecda] text-[#866a34]"}`}>
                        مباشر
                      </span>
                    </div>
                    <h4 className="mt-3 text-[1rem] font-black text-foreground">{item.label}</h4>
                    <p className="mt-2 text-sm leading-7 text-muted-foreground">{item.note}</p>
                    <div className="stat-meter mt-4"><span style={{ width: `${70 + index * 7}%` }} /></div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="container pb-16 sm:pb-20">
          <div className="cta-panel rounded-[36px] p-7 text-white shadow-[0_28px_70px_rgba(26,54,40,0.18)] sm:p-9 lg:p-12">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div className="max-w-2xl">
                <p className="text-sm font-bold text-[#a6e8c0]">الخطوة التالية</p>
                <h3 className="mt-3 text-[2rem] font-black leading-[1.35] sm:text-[2.7rem]">ابدأ تجربة تفاعلية تجعل طلابك ينتظرون الحصة القادمة</h3>
                <p className="mt-4 text-[0.98rem] leading-8 text-white/76">
                  أنشئ مسابقة أو اختبارًا أو فيديو تفاعليًا، وشارك الطلاب بكود واضح من 6 أرقام، ثم تابع الأثر من أول سؤال إلى آخر نتيجة.
                </p>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row">
                <Button
                  size="lg"
                  className="h-14 rounded-2xl bg-white px-8 text-base font-black text-[#234a35] hover:bg-white/92"
                  onClick={() => notify("يمكن ربط هذا الزر بصفحة إنشاء المسابقة أو النشاط لاحقًا.")}
                >
                  ابدأ أول تجربة الآن
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-14 rounded-2xl border-white/25 bg-white/8 px-8 text-base font-black text-white hover:bg-white/12"
                  onClick={() => notify("يمكن ربط الجولة السريعة أو صفحة العرض لاحقًا.")}
                >
                  شاهد جولة سريعة
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
